package org.cts.claims.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.cts.claims.model.*;
import org.cts.claims.util.DBConstants;
import org.cts.claims.util.DBUtil;

public class ClaimDaoImpl implements ClaimDao {
     
	
	Connection connection = null;
	
	@Override
	public String insertAutoClaim(Claim claim) {
		
		String msg=null;
		try
		{
			connection=DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL, DBConstants.UNAME, DBConstants.PWD);
			PreparedStatement pst=connection.prepareStatement("insert into claims(customer_id,claim_type,status,claim_set_date,claim_set_amt,policy_id,autoclaimsinfo_id) values(?,?,?,?,?,?,?)");
			//pst.setInt(1, claim.getId());
			pst.setInt(1, claim.getCustomer_id());
			//pst.setInt(3, claim.getAdjuster_id());
			pst.setString(2, "Auto");
			pst.setString(3, "Reported");
			pst.setString(4, claim.getClaim_set_date());
			pst.setDouble(5, claim.getClaim_set_amt());
			//pst.setDouble(7, claim.getSub_claim_amt());
			//pst.setDouble(8, claim.getSalvage_rec_amt());
			pst.setInt(6, claim.getPolicy_id());
			//pst.setInt(8, claim.getClaimsinfo_id());
			pst.setInt(7, claim.getAutoclaimsinfo_id());
			int r=pst.executeUpdate();
			if(r>0)
				msg="success";
			else
				msg="not success";
			
			connection.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return msg;

	
	}

public String insertPropertyClaim(Claim claim) {
		
		String msg=null;
		try
		{
			connection=DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL, DBConstants.UNAME, DBConstants.PWD);
			PreparedStatement pst=connection.prepareStatement("insert into claims(customer_id,status,claim_type,claim_set_date,claim_set_amt,policy_id,claimsinfo_id) values(?,?,?,?,?,?,?)");
			//pst.setInt(1, claim.getId());
			pst.setInt(1, claim.getCustomer_id());
			//pst.setInt(3, claim.getAdjuster_id());
			pst.setString(2,"Reported");
			pst.setString(3,"Property");
			pst.setString(4, claim.getClaim_set_date());
			pst.setDouble(5, claim.getClaim_set_amt());
			//pst.setDouble(7, claim.getSub_claim_amt());
			//pst.setDouble(8, claim.getSalvage_rec_amt());
			pst.setInt(6, claim.getPolicy_id());
			//pst.setInt(8, claim.getClaimsinfo_id());
			pst.setInt(7, claim.getClaimsinfo_id());
			int r=pst.executeUpdate();
			if(r>0)
				msg="success";
			else
				msg="not success";
			
			connection.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return msg;

	
	}

	@Override
	public List<Claim> search(String name) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public Claim getClaim(int cid) {
		Claim claim = null;
		try {
			    connection = DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,DBConstants.UNAME , DBConstants.PWD);
				PreparedStatement preparedStatement = connection.prepareStatement("select * from claims where id = ?");
				preparedStatement.setInt(1, cid);
				ResultSet resultSet  = preparedStatement.executeQuery();
				if(resultSet == null)
					return null;
				resultSet.next();
				claim = new Claim(resultSet.getInt(1),resultSet.getInt(2),resultSet.getInt(3), resultSet.getString(4), resultSet.getString(5),resultSet.getString(6),resultSet.getDouble(7), resultSet.getDouble(8),resultSet.getDouble(9), resultSet.getInt(10),resultSet.getInt(11),resultSet.getInt(12));
				connection.close();  
				
		  }
		  catch (Exception e) {
			  e.printStackTrace();
		  }
		// TODO Auto-generated method stub
		return claim;
	}



	@Override
	/*public List<Claim> getClaims() {
		List<Claim> claimsList = new ArrayList<>();
		try {
		    connection = DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,DBConstants.UNAME , DBConstants.PWD);
			PreparedStatement preparedStatement = connection.prepareStatement("select * from claims");
			ResultSet resultSet  = preparedStatement.executeQuery();
			while(resultSet.next()){
			claimsList.add(new Claim(resultSet.getInt(1),resultSet.getInt(2),resultSet.getString(3), resultSet.getString(4), resultSet.getDouble(5),resultSet.getDouble(6),resultSet.getDouble(7), resultSet.getInt(8),resultSet.getString(9), resultSet.getInt(10)));
			}
			connection.close(); 
			
			
	  }
	  catch (Exception e) {
		  e.printStackTrace();
	  }
	// TODO Auto-generated method stub
	return claimsList;
	}*/
	public String insert(int id,int cid,double am1,double am2,Claim claim)
	{
		
		String msg=null;
		try
		{
			connection=DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL, DBConstants.UNAME, DBConstants.PWD);
			PreparedStatement pst=connection.prepareStatement("update claims set sub_claim_amt = ? , salvage_rec_amt = ?,status = ? where id = ? and customer_id = ?");
			
			
			pst.setDouble(1, claim.getSub_claim_amt());
			pst.setDouble(2, claim.getSalvage_rec_amt());
			pst.setString(3, claim.getStatus());
			pst.setInt(4, claim.getId());
			pst.setInt(5, claim.getCustomer_id());
			int r=pst.executeUpdate();
			if(r>0)
				msg="success";
			else
				msg="not success";
			
			connection.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return msg;

	}
	
	public String insert(Claim claim)
	{
		
		String msg=null;
		try
		{
			connection=DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL, DBConstants.UNAME, DBConstants.PWD);
			PreparedStatement pst=connection.prepareStatement("update claims set claim_set_date = ?,status = ? where id = ? and claim_type = ?");
			
			
			pst.setString(1, claim.getClaim_set_date());
			pst.setString(2, claim.getStatus());
			pst.setInt(3, claim.getId());
			pst.setString(4, claim.getClaim_type());
			int r=pst.executeUpdate();
			if(r>0)
				msg="success";
			else
				msg="not success";
			
			connection.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return msg;

	}

	//@Override
	
}