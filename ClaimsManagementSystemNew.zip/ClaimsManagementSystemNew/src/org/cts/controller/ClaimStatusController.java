
package org.cts.controller;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/claimReport")
public class ClaimStatusController  extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        Connection conn = null;
        String url = "jdbc:mysql://localhost:3306/";
        String dbName = "ctsdb";
        String driver = "com.mysql.jdbc.Driver";
        String userName = "root";
        String password = "root";
        Statement st=null;
        try {
            Class.forName(driver).newInstance();
            conn = DriverManager.getConnection(url + dbName, userName, password);
            System.out.println("connected!.....");
            String status = request.getParameter("status");
            String s1 = request.getParameter("adjuster");
            String s2 = request.getParameter("cId");
            int adjuster_id = 0;
            int customer_id =0;
            if(s1!=null)
             adjuster_id = Integer.parseInt(s1);
            if(s2!=null)
             customer_id = Integer.parseInt(s2);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String fromDate = request.getParameter("fromDate");
            String toDate = request.getParameter("toDate");
//            Date fromDate = (Date) sdf.parse(request.getParameter("fromDate"));
//            Date toDate = (Date) sdf.parse(request.getParameter("fromDate"));
            if(fromDate!=null && toDate!=null){
                ArrayList al = null;
                ArrayList pid_list = new ArrayList();
                String query = "select * from claims";
                if(status!=null && !status.equals("")){
                    query = "select * from claims where claim_set_date between '" + fromDate + "' and '" + toDate + "'";
                }
                System.out.println("query " + query + " "+status);
                st = conn.createStatement();
                ResultSet rs = st.executeQuery(query);

                while (rs.next()) {
                    al = new ArrayList();

                    al.add(rs.getString(1));
                    al.add(rs.getString(2));
                    al.add(rs.getString(3));
                    al.add(rs.getString(4));
                    al.add(rs.getString(5));
                    al.add(rs.getString(6));
                    al.add(rs.getString(7));
                    al.add(rs.getString(8));
                    al.add(rs.getString(9));
                    System.out.println("al :: " + al);
                    pid_list.add(al);
                }
             // System.out.println(pid_list);
                request.setAttribute("piList", pid_list);
                RequestDispatcher searchStatus = request.getRequestDispatcher("SearchStatus.jsp");
                searchStatus.forward(request, response);
                conn.close();
                System.out.println("Disconnected!");
                
                }
                else 
            if(adjuster_id>0)
                {
                	
                	 ArrayList al = null;
                     ArrayList pid_list = new ArrayList();
                   //  String query = "select * from claims";
                  //   if(adjuster_id!=null && !adjuster_id.equals("")){
                       String  query = "select * from claims where adjuster_id='" + adjuster_id + "' ";
                   //  }
                     System.out.println("query " + query + " "+status);
                     st = conn.createStatement();
                     ResultSet rs = st.executeQuery(query);

                     while (rs.next()) {
                         al = new ArrayList();

                         al.add(rs.getString(1));
                         al.add(rs.getString(2));
                         al.add(rs.getString(3));
                         al.add(rs.getString(4));
                         al.add(rs.getString(5));
                         al.add(rs.getString(6));
                         al.add(rs.getString(7));
                         al.add(rs.getString(8));
                         al.add(rs.getString(9));
                         System.out.println("al :: " + al);
                         pid_list.add(al);
                     }
                  // System.out.println(pid_list);
                     request.setAttribute("piList", pid_list);
                     RequestDispatcher searchStatus = request.getRequestDispatcher("SearchStatus.jsp");
                     searchStatus.forward(request, response);
                     conn.close();
                     System.out.println("Disconnected!");
                }
            if(status!=null){
            ArrayList al = null;
            ArrayList pid_list = new ArrayList();
            String query = "select * from claims";
            if(status!=null && !status.equals("")){
                query = "select * from claims where status='" + status + "' ";
            }
            System.out.println("query " + query );
            st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);

            while (rs.next()) {
                al = new ArrayList();

                al.add(rs.getString(1));
                al.add(rs.getString(2));
                al.add(rs.getString(3));
                al.add(rs.getString(4));
                al.add(rs.getString(5));
                al.add(rs.getString(6));
                al.add(rs.getString(7));
                al.add(rs.getString(8));
                al.add(rs.getString(9));
                System.out.println("al :: " + al);
                pid_list.add(al);
            }
         // System.out.println(pid_list);
            request.setAttribute("piList", pid_list);
            RequestDispatcher searchStatus = request.getRequestDispatcher("SearchStatus.jsp");
            searchStatus.forward(request, response);
            conn.close();
            System.out.println("Disconnected!");
            
            }
            else  if(customer_id>0)
            {
            	
            	 ArrayList al = null;
                 ArrayList pid_list = new ArrayList();
               //  String query = "select * from claims";
              //   if(adjuster_id!=null && !adjuster_id.equals("")){
                   String  query = "select * from claims where customer_id='" + customer_id + "' ";
               //  }
                 System.out.println("query " + query );
                 st = conn.createStatement();
                 ResultSet rs = st.executeQuery(query);

                 while (rs.next()) {
                     al = new ArrayList();

                     al.add(rs.getString(1));
                     al.add(rs.getString(2));
                     al.add(rs.getString(3));
                     al.add(rs.getString(4));
                     al.add(rs.getString(5));
                     al.add(rs.getString(6));
                     al.add(rs.getString(7));
                     al.add(rs.getString(8));
                     al.add(rs.getString(9));
                     System.out.println("al :: " + al);
                     pid_list.add(al);
                 }
              // System.out.println(pid_list);
                 request.setAttribute("piList", pid_list);
                 RequestDispatcher searchStatus = request.getRequestDispatcher("SearchStatus.jsp");
                 searchStatus.forward(request, response);
                 conn.close();
                 System.out.println("Disconnected!");
            }
            else  if(adjuster_id>0)
            {
            	
            	 ArrayList al = null;
                 ArrayList pid_list = new ArrayList();
               //  String query = "select * from claims";
              //   if(adjuster_id!=null && !adjuster_id.equals("")){
                   String  query = "select * from claims where customer_id='" + customer_id + "' ";
               //  }
                 System.out.println("query " + query );
                 st = conn.createStatement();
                 ResultSet rs = st.executeQuery(query);

                 while (rs.next()) {
                     al = new ArrayList();

                     al.add(rs.getString(1));
                     al.add(rs.getString(2));
                     al.add(rs.getString(3));
                     al.add(rs.getString(4));
                     al.add(rs.getString(5));
                     al.add(rs.getString(6));
                     al.add(rs.getString(7));
                     al.add(rs.getString(8));
                     al.add(rs.getString(9));
                     System.out.println("al :: " + al);
                     pid_list.add(al);
                 }
              // System.out.println(pid_list);
                 request.setAttribute("piList", pid_list);
                 RequestDispatcher searchStatus = request.getRequestDispatcher("SearchStatus.jsp");
                 searchStatus.forward(request, response);
                 conn.close();
                 System.out.println("Disconnected!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
}